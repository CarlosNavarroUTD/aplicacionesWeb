import {Router} from 'express';
import {login, updateTime, getTime, getAllUsers} from '../controllers/auth.controller';


const router = Router();

router.post('/login-user', login); //routa del endpoint
router.get('/getTime/:userId', getTime)
router.patch('/updateTime', updateTime)
router.get('/users', getAllUsers)

export default router;